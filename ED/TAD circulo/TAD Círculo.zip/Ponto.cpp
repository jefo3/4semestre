// Este arquivo está parcialmente implementado. 
// Implemente o restante das operações do TAD Ponto

// Arquivo Ponto.cpp
// Implementacao do TAD Ponto
#include <iostream>
#include <cmath>
#include "Ponto.h"

struct Ponto {
    double x;
    double y;
}; 


// Libera a memoria de um ponto previamente criado
void pto_libera(Ponto *p) { 
    if(p != nullptr) {
        delete p;
        std::cout << "ponto liberado" << std::endl;
    }
} 